window.onload = function() {
  var c = document.getElementById("myCanvas");
  var ctx = c.getContext("2d");
  var img = document.getElementById("donator1");
  ctx.drawImage(img, 0, 0);
}

