$(document).ready(function(){
	$("#submit").click(function(){
		var Uname=$("#Uname").val();
		var message=$("#feedback").val();
		if(((Uname=="")||(feedback==""))==false){
			var obj={feedback:message};
			var objJSON=JSON.stringify(obj);
			localStorage.setItem(Uname,objJSON);
			$("#Uname").val("");
			$("#feedback").val("");
		}
		else{
			alert("fill all field");
		}
	});
})