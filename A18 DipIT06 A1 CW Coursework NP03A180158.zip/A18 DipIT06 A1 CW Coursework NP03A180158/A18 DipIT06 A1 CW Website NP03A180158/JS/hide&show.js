$("#show").click(function(){
    $("#location").toggle();
	  });
